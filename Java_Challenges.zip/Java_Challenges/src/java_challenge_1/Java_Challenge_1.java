/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package java_challenge_1;

import java.util.Scanner;
import JavaChallenges.JavaChallenges;

/**
 *
 * @author letem
 */
public class Java_Challenge_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner keyBoard = new Scanner(System.in);
        
        System.out.println("Introduce el tamaño del array");
        
        int sizeArray= keyBoard.nextInt();
        
        Integer [] numList2 = new Integer[sizeArray];
        
        for (int i = 0; i < sizeArray; i++) {
            
            System.out.println("Introduce un número");
            
            int numIntroducido=keyBoard.nextInt();
            
            numList2[i]=numIntroducido;
            
        }
        
        
        JavaChallenges n = new JavaChallenges();
        System.out.println("The largest integer in the list is: " +  n.maximum(numList2));
        
//        Integer [] numList = new Integer[]{4,5,7,8,16,3};
//        System.out.println("The largest integer in the list is: " + n.maximum(numList));
    }
  

}


