/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_Challenge_4;
import JavaChallenges.JavaChallenges;

/**
 *
 * @author letem
 */
public class java_Challenge_4 {
    public static void main(String[] args) {
    
    Integer [] numList = new Integer[]{4,5,7,8,16,3};
    JavaChallenges n = new JavaChallenges();
        System.out.println("The average is: " + n.average(numList));
    
    }
    
    

}
