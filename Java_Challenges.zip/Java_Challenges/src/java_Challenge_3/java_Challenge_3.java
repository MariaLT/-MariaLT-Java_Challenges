/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_Challenge_3;

import java.util.Scanner;
import JavaChallenges.JavaChallenges;

/**
 *
 * @author letem
 */
public class java_Challenge_3 {
    
    public static void main(String[] args) {
       Scanner keyBoard = new Scanner(System.in);

        System.out.println("Introduce un número: ");
        int numIntroducido = keyBoard.nextInt();
        
        JavaChallenges n = new JavaChallenges();
        
        n.checkOddEven(numIntroducido);
        

    }
    


    
}
