/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_challenge_2;

import java.util.Scanner;
import JavaChallenges.JavaChallenges;

/**
 *
 * @author letem
 */
public class java_challenge_2 {

    public static void main(String[] args) {

        Scanner keyBoard = new Scanner(System.in);
        JavaChallenges n = new JavaChallenges();

        System.out.println("Introduce un número: ");
        int numIntroducido = keyBoard.nextInt();

        System.out.println(n.printNumberInWord(numIntroducido));
         System.out.println(n.printNumberInWordSwitch(numIntroducido));

//        System.out.println(printNumberInWord(2));
//        System.out.println(printNumberInWordSwitch(2));
    }

}
