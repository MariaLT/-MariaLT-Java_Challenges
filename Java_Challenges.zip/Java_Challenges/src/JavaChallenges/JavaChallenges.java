/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JavaChallenges;

/**
 *
 * @author letem
 */
// Challenge 1: Find Maximum
public class JavaChallenges {

    public Integer maximum(Integer[] numList) {

        int largest = numList[0];

        for (int i = 0; i < numList.length; i++) {

            if (numList[i] > largest) {

                largest = numList[i];
            }

        }

        return largest;

    }
    // Challenge 2: Print number in word

    public String printNumberInWord(int num) {
        String numberInWord = "";
        if (num == 1) {
            numberInWord = "UNO";
        } else if (num == 2) {
            numberInWord = "DOS";
        } else if (num == 3) {
            numberInWord = "TRES";
        } else if (num == 4) {
            numberInWord = "CUATRO";
        } else if (num == 5) {
            numberInWord = "CINCO";
        } else if (num == 6) {
            numberInWord = "SEIS";
        } else if (num == 7) {
            numberInWord = "SIETE";
        } else if (num == 8) {
            numberInWord = "OCHO";
        } else if (num == 9) {
            numberInWord = "NUEVE";
        } else if (num == 10) {
            numberInWord = "DIEZ";
        } else if (num == 11) {
            numberInWord = "ONCE";
        } else {
            numberInWord = "OTRO";
        }
        return numberInWord;

    }

    public String printNumberInWordSwitch(int num) {
        String numberInWord = "";

        switch (num) {
            case 1:
                numberInWord = "UNO";
                break;

            case 2:
                numberInWord = "DOS";
                break;
            case 3:
                numberInWord = "TRES";
                break;
            case 4:
                numberInWord = "CUATRO";
                break;
            case 5:
                numberInWord = "CINCO";
                break;
            case 6:
                numberInWord = "SEIS";
                break;
            case 7:
                numberInWord = "SIETE";
                break;
            case 8:
                numberInWord = "OCHO";
                break;
            case 9:
                numberInWord = "NUEVE";
                break;
            case 10:
                numberInWord = "DIEZ";
                break;
            case 11:
                numberInWord = "ONCE";
                break;
            default:
                throw new AssertionError();
        }

        return numberInWord;

    }

    // Challenge 3: Check Odd/Even     
    public void checkOddEven(int num) {

        if (num % 2 == 0) {

            System.out.println("El número es par");

        } else if (num % 2 != 0) {

            System.out.println("El número es impar");

        }

    }

    // Challenge 4: Calculate the average
    public static double average(Integer[] listNum) {

        double average;
        double sum = 0;

        for (int i = 0; i < listNum.length; i++) {

            sum += listNum[i];

        }

        average = sum / listNum.length;

        return average;

    }
}
